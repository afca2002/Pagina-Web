
package vista;

import java.awt.Dimension;
import javax.swing.JDesktopPane;
// en este frm se crearan las diferentes ventanas que se usaran de acuerdo a los parametros del negocio



public class Menu extends javax.swing.JFrame {
    //Crea la ventana donde se van a "almacenar"  
    public static JDesktopPane jDesktopPane_menu;

    
    public Menu() {
        initComponents();
        this.setSize(new Dimension(1200, 700));
        this.setExtendedState(this.MAXIMIZED_BOTH);
        this.setLocationRelativeTo(null);
        this.setTitle("Sistema de Ventas");
        
        this.setLayout(null);
        jDesktopPane_menu = new JDesktopPane();

        int ancho = java.awt.Toolkit.getDefaultToolkit().getScreenSize().width;
        int alto = java.awt.Toolkit.getDefaultToolkit().getScreenSize().height;
        this.jDesktopPane_menu.setBounds(0, 0, ancho, alto);
        this.add(jDesktopPane_menu);
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jMenuItem1 = new javax.swing.JMenuItem();
        jMenuItem8 = new javax.swing.JMenuItem();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        MnNuevoUsuario = new javax.swing.JMenuItem();
        MnGestionarUsuario = new javax.swing.JMenuItem();
        jMenu2 = new javax.swing.JMenu();
        MnNuevoProducto = new javax.swing.JMenuItem();
        MnGestionarProducto = new javax.swing.JMenuItem();
        MnActualizarStock = new javax.swing.JMenuItem();
        JMenu2 = new javax.swing.JMenu();
        MnNuevoCliente = new javax.swing.JMenuItem();
        MnGestionarClientes = new javax.swing.JMenuItem();
        jMenu3 = new javax.swing.JMenu();
        MnNuevaCategoria = new javax.swing.JMenuItem();
        MnGestionarCategorias = new javax.swing.JMenuItem();
        jMenu4 = new javax.swing.JMenu();
        MnNuevaVenta = new javax.swing.JMenuItem();
        JMenu8 = new javax.swing.JMenu();
        MnCerrarSesion = new javax.swing.JMenuItem();

        jMenuItem1.setText("jMenuItem1");

        jMenuItem8.setText("jMenuItem8");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jMenu1.setText("Usuario");
        jMenu1.setPreferredSize(new java.awt.Dimension(150, 50));

        MnNuevoUsuario.setText("Nuevo Usuario");
        MnNuevoUsuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MnNuevoUsuarioActionPerformed(evt);
            }
        });
        jMenu1.add(MnNuevoUsuario);

        MnGestionarUsuario.setText("Gestionar Usuario");
        MnGestionarUsuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MnGestionarUsuarioActionPerformed(evt);
            }
        });
        jMenu1.add(MnGestionarUsuario);

        jMenuBar1.add(jMenu1);

        jMenu2.setText("Producto");
        jMenu2.setPreferredSize(new java.awt.Dimension(150, 50));

        MnNuevoProducto.setText("Nuevo Producto");
        MnNuevoProducto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MnNuevoProductoActionPerformed(evt);
            }
        });
        jMenu2.add(MnNuevoProducto);

        MnGestionarProducto.setText("Gestionar Producto");
        MnGestionarProducto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MnGestionarProductoActionPerformed(evt);
            }
        });
        jMenu2.add(MnGestionarProducto);

        MnActualizarStock.setText("Actualizar Stock");
        MnActualizarStock.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MnActualizarStockActionPerformed(evt);
            }
        });
        jMenu2.add(MnActualizarStock);

        jMenuBar1.add(jMenu2);

        JMenu2.setText("Cliente");
        JMenu2.setPreferredSize(new java.awt.Dimension(150, 50));

        MnNuevoCliente.setText("Nuevo Cliente");
        MnNuevoCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MnNuevoClienteActionPerformed(evt);
            }
        });
        JMenu2.add(MnNuevoCliente);

        MnGestionarClientes.setText("Gestionar Clientes ");
        MnGestionarClientes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MnGestionarClientesActionPerformed(evt);
            }
        });
        JMenu2.add(MnGestionarClientes);

        jMenuBar1.add(JMenu2);

        jMenu3.setText("Categoria");
        jMenu3.setPreferredSize(new java.awt.Dimension(150, 50));

        MnNuevaCategoria.setText("Nueva Categoria");
        MnNuevaCategoria.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MnNuevaCategoriaActionPerformed(evt);
            }
        });
        jMenu3.add(MnNuevaCategoria);

        MnGestionarCategorias.setText("Gestionar Categorias");
        MnGestionarCategorias.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MnGestionarCategoriasActionPerformed(evt);
            }
        });
        jMenu3.add(MnGestionarCategorias);

        jMenuBar1.add(jMenu3);

        jMenu4.setText("Factura");
        jMenu4.setPreferredSize(new java.awt.Dimension(150, 50));

        MnNuevaVenta.setText("Nueva venta");
        MnNuevaVenta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MnNuevaVentaActionPerformed(evt);
            }
        });
        jMenu4.add(MnNuevaVenta);

        jMenuBar1.add(jMenu4);

        JMenu8.setText("Cerrar Sesion");
        JMenu8.setPreferredSize(new java.awt.Dimension(150, 50));

        MnCerrarSesion.setText("Cerrar sesion");
        MnCerrarSesion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MnCerrarSesionActionPerformed(evt);
            }
        });
        JMenu8.add(MnCerrarSesion);

        jMenuBar1.add(JMenu8);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1200, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 649, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void MnGestionarProductoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MnGestionarProductoActionPerformed
        InterGestionarProducto interGestionarProducto=new InterGestionarProducto();
        jDesktopPane_menu.add(interGestionarProducto);
        interGestionarProducto.setVisible(true);
    }//GEN-LAST:event_MnGestionarProductoActionPerformed

    private void MnNuevaCategoriaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MnNuevaCategoriaActionPerformed
        InterCategorias interCategoria=new InterCategorias();
        jDesktopPane_menu.add(interCategoria);
        interCategoria.setVisible(true);
    }//GEN-LAST:event_MnNuevaCategoriaActionPerformed

    private void MnGestionarCategoriasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MnGestionarCategoriasActionPerformed
        InterGestionarCategorias interGestionarCategoria = new InterGestionarCategorias();
        jDesktopPane_menu.add(interGestionarCategoria);
        interGestionarCategoria.setVisible(true);
    }//GEN-LAST:event_MnGestionarCategoriasActionPerformed

    private void MnNuevoClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MnNuevoClienteActionPerformed
        InterCliente interCliente = new InterCliente();
        jDesktopPane_menu.add(interCliente);
        interCliente.setVisible(true);
    }//GEN-LAST:event_MnNuevoClienteActionPerformed

    private void MnCerrarSesionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MnCerrarSesionActionPerformed
        //metodo para salir y finalizar el programa de manera controlada 
        System.exit(0);
        
    }//GEN-LAST:event_MnCerrarSesionActionPerformed

    private void MnGestionarClientesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MnGestionarClientesActionPerformed
        // todos los metoso para que se despligue le menu son copiados unos de 
        //otros ya que son los mismos solo que con distintas variables de acuerdo a la necesidad 
         InterGestionarCliente interGestionarCliente = new InterGestionarCliente();
        jDesktopPane_menu.add(interGestionarCliente);
        interGestionarCliente.setVisible(true);
    }//GEN-LAST:event_MnGestionarClientesActionPerformed

    private void MnActualizarStockActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MnActualizarStockActionPerformed

        InterActualizarStock interActualizarStock = new InterActualizarStock();
        jDesktopPane_menu.add(interActualizarStock);
        interActualizarStock.setVisible(true);
    }//GEN-LAST:event_MnActualizarStockActionPerformed

    private void MnNuevoUsuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MnNuevoUsuarioActionPerformed
        InterUsuario interUsuario = new InterUsuario();
        jDesktopPane_menu.add(interUsuario);
        interUsuario.setVisible(true);
    }//GEN-LAST:event_MnNuevoUsuarioActionPerformed

    private void MnGestionarUsuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MnGestionarUsuarioActionPerformed
        InterGestionarUsuario interGestionarUsuario = new InterGestionarUsuario();
        jDesktopPane_menu.add(interGestionarUsuario);
        interGestionarUsuario.setVisible(true);
    }//GEN-LAST:event_MnGestionarUsuarioActionPerformed

    private void MnNuevaVentaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MnNuevaVentaActionPerformed
        InterFacturacion interfacturacion = new InterFacturacion();
        jDesktopPane_menu.add(interfacturacion);
        interfacturacion.setVisible(true);

    }//GEN-LAST:event_MnNuevaVentaActionPerformed

    private void MnNuevoProductoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MnNuevoProductoActionPerformed
        InterProducto interProducto=new InterProducto();
        jDesktopPane_menu.add(interProducto);
        interProducto.setVisible(true);
    }//GEN-LAST:event_MnNuevoProductoActionPerformed

    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Menu().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenu JMenu2;
    private javax.swing.JMenu JMenu8;
    private javax.swing.JMenuItem MnActualizarStock;
    private javax.swing.JMenuItem MnCerrarSesion;
    private javax.swing.JMenuItem MnGestionarCategorias;
    private javax.swing.JMenuItem MnGestionarClientes;
    private javax.swing.JMenuItem MnGestionarProducto;
    private javax.swing.JMenuItem MnGestionarUsuario;
    private javax.swing.JMenuItem MnNuevaCategoria;
    private javax.swing.JMenuItem MnNuevaVenta;
    private javax.swing.JMenuItem MnNuevoCliente;
    private javax.swing.JMenuItem MnNuevoProducto;
    private javax.swing.JMenuItem MnNuevoUsuario;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenu jMenu4;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem8;
    // End of variables declaration//GEN-END:variables
}
