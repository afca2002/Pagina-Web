function [row, col] = playAgentStudent(board)
% playAgentStudent implementa un agente que juega un juego m,n,k usando
% �rboles.
%
% Entradas:
%
%         - board: [mxn] matriz conteniendo el estado actual del juego.
%                  Cada posici�n de esta matriz contiene un elemento del
%                  conjunto {0, 1, 2}. La codificaci�n es la siguiente:
%                  0 = posici�n disponible
%                  1 = posici�n ocupada por el agente del estudiante
%                  2 = posici�n ocupada por el agente del profesor o el
%                      agente manual
% Salidas:
%
%           - row: [1x1] entero del conjunto {1, 2, ..., m} que indica la fila donde
%                  el estudiante ha colocado la marca actual
%           - col: [1x1] entero del conjunto {1, 2, ..., n} que indica la columna donde
%                  el estudiante ha colocado la marca actual
%             
%


% REEMPLAZAR LA SIGUIENTE FUNCI�N CON EL C�DIGO SU AGENTE
%[row, col]
% = playRandomly(board); 

%[row,col]=casillaOptima(board);

% Lee hoja de calculo excel
    tableroideal=readcell("Book1.xlsx","Sheet","Sheet2","Range","a1:ab42");
    tableroreal=readcell("Book1.xlsx","Sheet","Sheet2","Range","ad1:be42");
    availablepositions=find(board==0);


    %Si hay 49 posiciones (tablero vacío), ocupa la casilla de la mitad

    if (length(availablepositions)==49)
        row=4;
        col=4;
        return
    end

    %Si hay 48 posiciones (nos toca el segundo turno), y si la casilla del
    %medio no esta ocupada, la ocupamos, sino utilizamos la casilla en las
    %coordenadas (5, 5)
    if (length(availablepositions)==48)
        if board(25)==0
        row=4;
        col=4;
        return
        else 
        row=5;
        col=5;
        return
        end
    end

    %Si hay 47 posiciones, invocamos la función primerajugada y devolvemos
    %la coordenada

    if (length(availablepositions)==47)
        [row,col]=primerajugada(board);
        return
    end
    
    %Arreglando la jugada del inicio (había una jugada al
    % inicio en la que siempre perdía)
    
    if(length(availablepositions)==44)
        if(board(25)&&board(31)&&board(19)==2)
            row=6;
            col=2;
            return
        end
    end

    %Si encuentra la posibilidad de hacer 4 en calle se invoca a la función
    %ganarauto y ganamos

    [row1,col1]=ganarauto(board,1);
        if row1~=0
            row=row1;
            col=col1;
            return
        end

    [row1,col1]=ganarauto(board,2);
        if row1~=0
            row=row1;
            col=col1;
            return
        end

        %Llamar funciones para intentar hacer un 3 en linea
    [row1,col1]=tresenlinea(board,1);
        if row1~=0
            row=row1;
            col=col1;
            return
        end

        [row1,col1]=tresenlinea(board,2);
        if row1~=0
            row=row1;
            col=col1;
            return
        end

        %Uso de capicuas generales para que en el caso de que el tablero de
        %juego sea igual a los tableros de la hoja de excel, ejecute la
        %mejor jugada

    [row1,col1]=capicuas_generales(tableroreal,tableroideal,board);
        if row1~=0
            row=row1;
            col=col1;
            return
        end

        %Si el juego continúa, llamamos al algoritmo minimax

    highscore=0;
    for i=1:length(board)
        board ( availablepositions(i))=1;
        nextavailable=find(board==0);
        score = min_(board,0,-Inf, Inf , nextavailable, highscore);
        board ( availablepositions(i))=0;
        if score>highscore
             col1=floor((availablepositions(i)./7)-0.1)+1;
             row1=mod(availablepositions(i),7);
             if row1==0
                 row1=1;
             end
        end
        col=col1;
        row=row1;
    end

end