function [highscore] = min_(visionboard,deep,alfa,beta,availablepositions,highscore)

%Invocamos a la funcion definirganador y guardamos el resultado en winner

winner=definirganador(visionboard);
a=0; %Bandera

%Casos base para algoritmo minimax con recursividad

if winner==1 
    highscore=100;
    a=1;
elseif winner==2
    highscore=-100;
    a=1;
elseif deep>4
    highscore=10;
    a=1;
end

%Si no cumple ninguno de los anteriores (a~=1), ejecuta minimax con poda
%alfa-beta

if a~=1
    highscore=Inf;
    for i=1:length(availablepositions)
        visionboard(availablepositions(i))=2;
        nextavailable=find(visionboard==0);
        score=max_(visionboard,deep+1,alfa,beta,nextavailable,highscore);
        visionboard(availablepositions(i))=0;
        if score>highscore
            highscore=score;
        end
        beta=min(alfa,highscore);
        if beta <= alfa
            break
        end
    end
end