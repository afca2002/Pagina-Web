function [row,col] = ganarauto(tablero,player)

row=0; col=0;
[a,b]=find(tablero==0);
    tableroaux=tablero;
    for i=1:length(a)
       tableroaux(a(i,1),b(i,1))=player;
       if definirganador(tableroaux)==player
           row=a(i,1);
           col=b(i,1);
           break
       end
       tableroaux(a(i),b(i))=0;
    end
end
