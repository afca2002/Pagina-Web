function [row,col] = capicuas_generales(tableroreal,tableroideal,tablero)
k=1;
for j=1:7:22
    for i=1:7:36
        tablerosreales{k}=tableroreal(i:i+6,j:j+6);
        tablerosideales{k}=tableroideal(i:i+6,j:j+6);
        k=k+1;
    end
end
for i=1:length(tablerosideales)
    tablerorealmatriz(:,:,i)=cell2mat(tablerosreales{1}); 
    tableroidealmatriz(:,:,i)=cell2mat(tablerosideales{1});
    if tablerorealmatriz(:,:,i)==tablero
        tablero=tableroidealmatriz(:,:,i);
    elseif rot90(tablerorealmatriz(:,:,i))==tablero
        tablero=rot90(tableroidealmatriz(:,:,i));
    elseif rot90(tablerorealmatriz(:,:,i),2)==tablero
        tablero=rot90(tableroidealmatriz(:,:,i),2);
    elseif rot90(tablerorealmatriz(:,:,i),3)==tablero
        tablero=rot90(tableroidealmatriz(:,:,i),3);   
    end
end
[row,col]=find(tablero==0.5);

end