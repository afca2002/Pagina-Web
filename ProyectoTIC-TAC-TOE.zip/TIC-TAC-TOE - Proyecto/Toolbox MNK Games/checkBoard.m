function status = checkBoard(board)
% checkBoard5x5 checks the current status of the board to determine the
% current status of the game.
%
% Syntaxis:
%
% status = checkBoard(board)
%
% Input:
%
% board: [5x5] or [3x3] matrix of integers where each element is either 0, 1, or 2:
%
% 0 = available position
% 1 = positions chosen by agent 1
% 2 = positions chosen by agent 2
%
% Output:
%
% status: structure with the fields 'state' and 'winner'. When there is
% a winner status.state = 'win' and status.winner indicates which agent
% won. When the game is still in progress, then status.state = 'inProgress'
% and status.winner = []
%


[m, n] = size(board);
if m == n
    if m == 3
        status = checkBoard3x3(board);
    end
    if m == 7
        status = checkBoard7x7(board);
    end
else
    error('El tablero a evaluar no tiene el tamaño permitido');
end
end

function status = checkBoard7x7(board)
% checkBoard7x7 checks the current status of the board to determine the
% current status of the game.
%
% Syntaxis:
%
% status = checkBoard(board)
%
% Input:
%
% board: [7x7] matrix of integers where each element is either 0, 1, or 2:
%
% 0 = available position
% 1 = positions chosen by agent 1
% 2 = positions chosen by agent 2
%
% Output:
%
% status: structure with the fields 'state' and 'winner'. When there is
% a winner status.state = 'win' and status.winner indicates which agent
% won. When the game is still in progress, then status.state = 'inProgress'
% and status.winner = []
%


if size(board,1) ~= 7 || size(board,2) ~= 7
    error('La matriz del juego no es de 7 x 7');
else
    %% Player 1:
    for i = 1:4 % Rows
        idxStart = i;
        idxEnd = 3 + i;
        if ~isempty(  find( sum( board(:, idxStart:idxEnd) == 1, 2 ) == 4, 1 )  )
            status.state = 'win';
            status.winner = 1;
            status.line = 'row';
            % Indices to highlight the wining states
            r = find( sum( board(:, idxStart:idxEnd) == 1, 2 ) == 4, 1 );
            col = idxStart:idxEnd;
            row = r*ones(1, length(col));
            status.idx = sub2ind([7,7],row,col);
            return;
        end
    end
    
    for i = 1:4 % Columns
        idxStart = i;
        idxEnd = 3 + i;
        if ~isempty(  find( sum( board(idxStart:idxEnd, :) == 1, 1 ) == 4, 1 )  )
            status.state = 'win';
            status.winner = 1;
            status.line = 'col';
            % Indices to highlight the wining states
            c = find( sum( board(idxStart:idxEnd, :) == 1, 1 ) == 4, 1 );
            row = idxStart:idxEnd;
            col = c*ones(1, length(row));
            status.idx = sub2ind([7,7],row,col);
            return;
        end
    end
    
    % Main diagonals
    % (1,1), (2,2), (3,3), (4,4)
    % (2,2), (3,3), (4,4), (5,5)
    % (3,3), (4,4), (5,5), (6,6)
    % (4,4), (5,5), (6,6), (7,7)
    % (2,1), (3,2), (4,3), (5,4)
    % (3,2), (4,3), (5,4), (6,5)
    % (4,3), (5,4), (6,5), (7,6)
    % (3,1), (4,2), (5,3), (6,4)
    % (4,2), (5,3), (6,4), (7,5)
    % (4,1), (5,2), (6,3), (7,4)
    % (1,2), (2,3), (3,4), (4,5)
    % (2,3), (3,4), (4,5), (5,6)
    % (3,4), (4,5), (5,6), (6,7)
    % (1,3), (2,4), (3,5), (4,6)
    % (2,4), (3,5), (4,6), (5,7)
    % (1,4), (2,5), (3,6), (4,7)
    r = [1:4; 2:5; 3:6; 4:7; 2:5; 3:6; 4:7; 3:6; 4:7; 4:7; 1:4; 2:5; 3:6; 1:4; 2:5; 1:4];
    c = [1:4; 2:5; 3:6; 4:7; 1:4; 2:5; 3:6; 1:4; 2:5; 1:4; 2:5; 3:6; 4:7; 3:6; 4:7; 4:7];
    for i = 1:16
        idx = sub2ind([7,7],r(i,:),c(i,:));
        sumVal = sum( board( idx ) == 1 );
        if sumVal == 4
            status.state = 'win';
            status.winner = 1;
            status.line = 'mDiag';
            % Indices to highlight the wining states
            status.idx = idx;
            return;
        end
    end
    
    % Secondary diagonals: rotation of 90 deegrees
    for i = 1:16
        idx = sub2ind([7,7],r(i,:),c(i,:));
        mtx = zeros(7,7);
        mtx(idx) = 1;
        mtx90 = logical(rot90(mtx, 1));
        sumVal = sum( board( mtx90 ) == 1 );
        if sumVal == 4
            status.state = 'win';
            status.winner = 1;
            status.line = 'sDiag';
            % Indices to highlight the wining states
            status.idx = find( mtx90 == 1 );
            return;
        end
    end
    
    %% Player 2:
    for i = 1:4 % Rows
        idxStart = i;
        idxEnd = 3 + i;
        if ~isempty(  find( sum( board(:, idxStart:idxEnd) == 2, 2 ) == 4, 1 )  )
            status.state = 'win';
            status.winner = 2;
            status.line = 'row';
            % Indices to highlight the wining states
            r = find( sum( board(:, idxStart:idxEnd) == 2, 2 ) == 4, 1 );
            col = idxStart:idxEnd;
            row = r*ones(1, length(col));
            status.idx = sub2ind([7,7],row,col);
            return;
        end
    end
    
    for i = 1:4 % Columns
        idxStart = i;
        idxEnd = 3 + i;
        if ~isempty(  find( sum( board(idxStart:idxEnd, :) == 2, 1 ) == 4, 1 )  )
            status.state = 'win';
            status.winner = 2;
            status.line = 'col';
            % Indices to highlight the wining states
            c = find( sum( board(idxStart:idxEnd, :) == 2, 1 ) == 4, 1 );
            row = idxStart:idxEnd;
            col = c*ones(1, length(row));
            status.idx = sub2ind([7,7],row,col);
            return;
        end
    end
    
    % Main diagonals
    % (1,1), (2,2), (3,3), (4,4)
    % (2,2), (3,3), (4,4), (5,5)
    % (3,3), (4,4), (5,5), (6,6)
    % (4,4), (5,5), (6,6), (7,7)
    % (2,1), (3,2), (4,3), (5,4)
    % (3,2), (4,3), (5,4), (6,5)
    % (4,3), (5,4), (6,5), (7,6)
    % (3,1), (4,2), (5,3), (6,4)
    % (4,2), (5,3), (6,4), (7,5)
    % (4,1), (5,2), (6,3), (7,4)
    % (1,2), (2,3), (3,4), (4,5)
    % (2,3), (3,4), (4,5), (5,6)
    % (3,4), (4,5), (5,6), (6,7)
    % (1,3), (2,4), (3,5), (4,6)
    % (2,4), (3,5), (4,6), (5,7)
    % (1,4), (2,5), (3,6), (4,7)
    r = [1:4; 2:5; 3:6; 4:7; 2:5; 3:6; 4:7; 3:6; 4:7; 4:7; 1:4; 2:5; 3:6; 1:4; 2:5; 1:4];
    c = [1:4; 2:5; 3:6; 4:7; 1:4; 2:5; 3:6; 1:4; 2:5; 1:4; 2:5; 3:6; 4:7; 3:6; 4:7; 4:7];
    for i = 1:16
        idx = sub2ind([7,7],r(i,:),c(i,:));
        sumVal = sum( board( idx ) == 2 );
        if sumVal == 4
            status.state = 'win';
            status.winner = 2;
            status.line = 'mDiag';
            % Indices to highlight the wining states
            status.idx = idx;
            return;
        end
    end
    
    % Secondary diagonals: rotation of 90 deegrees
    for i = 1:16
        idx = sub2ind([7,7],r(i,:),c(i,:));
        mtx = zeros(7,7);
        mtx(idx) = 1;
        mtx90 = logical(rot90(mtx, 1));
        sumVal = sum( board( mtx90 ) == 2 );
        if sumVal == 4
            status.state = 'win';
            status.winner = 2;
            status.line = 'sDiag';
            % Indices to highlight the wining states
            status.idx = find( mtx90 == 1 );
            return;
        end
    end
    
    % Check for draws otherwise the game is still in progress
    if sum(board(:) == 0) == 0
        status.state = 'draw';
        status.winner = [];
        status.line = [];
        status.idx = [];
        return;
    else
        status.state = 'inProgress';
        status.winner = [];
        status.line = [];
        status.idx = [];
    end
end
end

function status = checkBoard3x3(board)
% checkBoard(board) checks the current status of the board to determine the
% current status of the game.
%
% Syntaxis:
%
% status = checkBoard(board)
%
% Input:
%
% board: [3x3] matrix of integers where each element is either 0, 1, or 2:
%
% 0 = available position
% 1 = positions chosen by agent 1
% 2 = positions chosen by agent 2
%
% Output:
%
% status: structure with the fields 'state' and 'winner'. When there is
% a winner status.state = 'win' and status.winner indicates which agent
% won. When the game is still in progress, then status.state = 'inProgress'
% and status.winner = []
%

% playAgentProfessor implements an agent for playing tic-tac-toe. This
% function chooses randomly an empty position (row,col) on the board.
%
% Syntaxis:
%
% [row, col] = playAgentProfessor(board)
%
% Input:
%
% board: [3x3] matrix of integers where each element is either 0, 1, or 2:
%
% 0 = available position
% 1 = positions chosen by agent 1
% 2 = positions chosen by agent 2
%
% Output:
%
% [row, col]: Denotes the position (row, col) chosen by the agent implemented
%             by the professor
%


if size(board,1) ~= 3 || size(board,2) ~= 3
    error('La matriz del juego no es de 3 x 3');
else
    % Player 1:
    if ~isempty(  find( sum( board == 1, 2 ) == 3, 1 )  )
        status.state = 'win';
        status.winner = 1;
        status.line = 'row';
        % Indices to highlight the wining states
        r = find( sum( board == 1, 2 ) == 3, 1 );
        col = 1:3;
        row = r*ones(1, length(col));
        status.idx = sub2ind([3,3],row,col);
        return;
    elseif ~isempty(  find( sum( board == 1, 1 ) == 3, 1 )  )
        status.state = 'win';
        status.winner = 1;
        status.line = 'col';
        % Indices to highlight the wining states
        c = find( sum( board == 1, 1 ) == 3, 1 );
        row = 1:3;
        col = c*ones(1, length(row));
        status.idx = sub2ind([3,3],row,col);
        return;
    elseif sum(sum( (board == 1).*eye(3,3) ) ) == 3
        status.state = 'win';
        status.winner = 1;
        status.line = 'mDiag';
        row = 1:3;
        col = 1:3;
        status.idx = sub2ind([3,3],row,col);
        return;
    elseif sum(sum( (board == 1).*rot90(eye(3), 1) ) ) == 3
        status.state = 'win';
        status.winner = 1;
        status.line = 'sDiag';                
        row = 1:3;
        col = 3:-1:1;
        status.idx = sub2ind([3,3],row,col);
        return;
    end
    % Player 2:
    if ~isempty(  find( sum( board == 2, 2 ) == 3, 1 )  )
        status.state = 'win';
        status.winner = 2;
        status.line = 'row';
        % Indices to highlight the wining states
        r = find( sum( board == 2, 2 ) == 3, 1 );
        col = 1:3;
        row = r*ones(1, length(col));
        status.idx = sub2ind([3,3],row,col);
        return;
    elseif ~isempty(  find( sum( board == 2, 1 ) == 3, 1 )  )
        status.state = 'win';
        status.winner = 2;
        status.line = 'col';
         % Indices to highlight the wining states
        c = find( sum( board == 2, 1 ) == 3, 1 );
        row = 1:3;
        col = c*ones(1, length(row));
        status.idx = sub2ind([3,3],row,col);
        return;
    elseif sum(sum( (board == 2).*eye(3,3) ) ) == 3
        status.state = 'win';
        status.winner = 2;
        status.line = 'mDiag';
        row = 1:3;
        col = 1:3;
        status.idx = sub2ind([3,3],row,col);
        return;
    elseif sum(sum( (board == 2).*rot90(eye(3), 1) ) ) == 3
        status.state = 'win';
        status.winner = 2;
        status.line = 'sDiag';
        row = 1:3;
        col = 3:-1:1;
        status.idx = sub2ind([3,3],row,col);
        return;
    elseif sum(board(:) == 0) == 0
        status.state = 'draw';
        status.winner = [];
        status.line = [];
        status.idx = [];
        return;
    else
        status.state = 'inProgress';
        status.winner = [];
        status.line = [];
        status.idx = [];
    end
end
end