function [row, col] = playRandomly(board)
[m, n] = size(board);
board = board';
board = board(:)';
if m == n
    % Encuentra las posiciones que no han sido ocupadas por ning�n jugador
    vector = 1:49;
    availablePositions = vector(board == 0);
    % Selecciona aleatoriamente una posici�n vac�a
    [dummy, idx] = sort(  rand( size(availablePositions) )  );
    [col, row] = ind2sub(  [7,7], availablePositions( idx(1) )  );
else
    error('El tablero a evaluar no tiene el tama�o permitido');
end
end