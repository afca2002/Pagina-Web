function [row1,col1] = primerajugada(tablero)

% Asigna a la estructura "play" los cuatro posibles cuadrantes del tablero,
% rotados 0, 90, 180 y 270 grados.

play(4).cuadrant=tablero;
play(3).cuadrant=rot90(tablero,3);
play(2).cuadrant=rot90(tablero,2);
play(1).cuadrant=rot90(tablero);

% Se itera sobre los cuatro cuadrantes del tablero para encontrar la jugada
% del rival en ese cuadrante, y asignar el valor de la variable
% "jugadarival".

for i=1:4
    play(i).jugadarival=find(play(i).cuadrant(1:4,5:7)==2);

% Dependiendo del valor de "jugadarival", se asigna una jugada
% particular en el cuadrante correspondiente.

    if play(i).jugadarival==10 
        play(i).cuadrant(3,3)=1;
        tableroaux=rot90(play(i).cuadrant,-i);
    elseif play(i).jugadarival==7
        play(i).cuadrant(3,3)=1;
        tableroaux=rot90(play(i).cuadrant,-i);
    end

    if play(i).jugadarival==1
        play(i).cuadrant(3,5)=1;
        tableroaux=rot90(play(i).cuadrant,-i);
    elseif play(i).jugadarival==4
        play(i).cuadrant(3,5)=1;
        tableroaux=rot90(play(i).cuadrant,-i);
    elseif play(i).jugadarival==11
        play(i).cuadrant(3,5)=1;
        tableroaux=rot90(play(i).cuadrant,-i);
    elseif play(i).jugadarival==12
        play(i).cuadrant(3,5)=1;
        tableroaux=rot90(play(i).cuadrant,-i);
    end

    if play(i).jugadarival==2
        play(i).cuadrant(5,5)=1;
        tableroaux=rot90(play(i).cuadrant,-i);
    elseif play(i).jugadarival==5
        play(i).cuadrant(5,5)=1;
        tableroaux=rot90(play(i).cuadrant,-i);
    elseif play(i).jugadarival==9
        play(i).cuadrant(5,5)=1;
        tableroaux=rot90(play(i).cuadrant,-i);
    end

    if play(i).jugadarival==8
        play(i).cuadrant(6,4)=1;
        tableroaux=rot90(play(i).cuadrant,-i);
    end

    if play(i).jugadarival==3 
        play(i).cuadrant(4,7)=1;
        tableroaux=rot90(play(i).cuadrant,-i);
    elseif play(i).jugadarival==6
        play(i).cuadrant(4,7)=1;
        tableroaux=rot90(play(i).cuadrant,-i);
    end
end
    
% Encuentra la posición de la única casilla que no ha sido ocupada por el
% rival en el cuadrante resultante de aplicar la jugada que corresponde.
    [row, col]=find(tableroaux==1);
for i=1:length(row)
    if and(row(i,1)==4,col(i,1)==4)
    else
         row1=row(i,1);
         col1=col(i,1);
    end
end
end