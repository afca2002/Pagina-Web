function [row1,col1] = casillaOptima(visionboard)

    tableroideal=readcell("Book1.xlsx","Sheet","Sheet2","Range","a1:ab42");
    tableroreal=readcell("Book1.xlsx","Sheet","Sheet2","Range","ad1:be42");
    availablepositions=find(visionboard==0);

    if (length(availablepositions)==49)
        row1=4;
        col1=4;
        return
    end

    if (length(availablepositions)==48)
        if visionboard(25)==0
        row1=4;
        col1=4;
        return
        else 
        row1=5;
        col1=5;
        return
        end
    end

    if (length(availablepositions)==47)
        [row1,col1]=primerajugada(visionboard);
        return
    end

    [row,col]=ganarauto(visionboard,1);
        if row~=0
            row1=row;
            col1=col;
            return
        end

    [row,col]=ganarauto(visionboard,2);
        if row~=0
            row1=row;
            col1=col;
            return
        end

    [row,col]=tresenlinea(visionboard,1);
        if row~=0
            row1=row;
            col1=col;
            return
        end

        [row,col]=tresenlinea(visionboard,2);
        if row~=0
            row1=row;
            col1=col;
            return
        end

    [row,col]=capicuas_generales(tableroreal,tableroideal,visionboard);
        if row~=0
            row1=row;
            col1=col;
            return
        end

    highscore=0;
    for i=1:length(visionboard)
        visionboard ( availablepositions(i))=1;
        nextavailable=find(visionboard==0);
        score = min_(visionboard,0,-Inf, Inf , nextavailable, highscore);
        visionboard ( availablepositions(i))=0;
        if score>highscore
             col=floor((availablepositions(i)./7)-0.1)+1;
             row=mod(availablepositions(i),7);
             if row==0
                 row=1;
             end
        end
        col1=col;
        row1=row;
    end
        
       
        

end