function [ganador,matriz] = definirganador(matriz)
 
%Posibles combinaciones para ganar el juego

 dos=2*ones(4,1);
      diagonalppal=diag(matriz,0);
      diagonalppalflip=diag(flip(matriz,2),0);
      
      diagonal2(:,1)=diag(matriz,1);
      diagonal2flip(:,1)=diag(flip(matriz,2),1);
      diagonal2(:,2)=diag(matriz,-1);
      diagonal2flip(:,2)=diag(flip(matriz,2),-1);

      diagonal3(:,1)=diag(matriz,2);
      diagonal3flip(:,1)=diag(flip(matriz,2),2);
      diagonal3(:,2)=diag(matriz,-2);
      diagonal3flip(:,2)=diag(flip(matriz,2),-2);

      diagonal4(:,1)=diag(matriz,3);
      diagonal4flip(:,1)=diag(flip(matriz,2),3);
      diagonal4(:,2)=diag(matriz,-3);
      diagonal4flip(:,2)=diag(flip(matriz,2),-3);

      ganador=0;
 for i=1:4
     for j=1:7
    if ones(1,4)==matriz(j,i:i+3)
        ganador=1;
    elseif 2*ones(1,4)==matriz(j,i:i+3)
        ganador=2;
    elseif ones(4,1)==matriz(i:i+3,j)
        ganador=1;
    elseif 2*ones(4,1)==matriz(i:i+3,j)
        ganador=2;
    end
     end
    if ones(4,1)==diagonalppal(i:i+3,1) 
       ganador=1;
    elseif ones(4,1)==diagonalppalflip(i:i+3,1)
       ganador=1;
    elseif or(2*ones(4,1)==diagonalppal(i:i+3,1), 2*ones(4,1)==diagonalppalflip(i:i+3,1))
       ganador=2;
    end
 end

 for i=1:3
     if ones(4,1)==diagonal2(i:i+3,2)
         ganador=1;
     elseif ones(4,1)==diagonal2flip(i:i+3,2)
         ganador=1;
     elseif ones(4,1)==diagonal2(i:i+3,1) 
         ganador=1;
     elseif ones(4,1)==diagonal2flip(i:i+3,1)
         ganador=1;
     elseif 2*ones(4,1)==diagonal2(i:i+3,2) 
         ganador=2;
     elseif 2*ones(4,1)==diagonal2flip(i:i+3,2)
         ganador=2;
     elseif 2*ones(4,1)==diagonal2(i:i+3,1) 
         ganador=2;
     elseif 2* ones(4,1)==diagonal2flip(i:i+3,1)
         ganador=2;
     end
 end

  for i=1:2
    if ones(4,1)==diagonal3(i:i+3,2)
        ganador=1;
    elseif ones(4,1)==diagonal3flip(i:i+3,2)
        ganador=1;
    elseif ones(4,1)==diagonal3(i:i+3,1)
        ganador = 1 ;
    elseif ones(4,1)==diagonal3flip(i:i+3,1)
        ganador=1;
    elseif  diagonal3flip(i:i+3,1)==dos
        ganador=2;
    elseif dos==diagonal3(i:i+3,1) 
        ganador=2;
    elseif  dos==diagonal3flip(i:i+3,2)
        ganador=2;
    elseif dos==diagonal3(i:i+3,2)
        ganador=2;
    end
 end
 
 if ones(4,1)==diagonal4(1:4,2) 
     ganador=1;
 elseif ones(4,1)==diagonal4flip(1:4,2)
     ganador=1;
 elseif ones(4,1)==diagonal4(1:4,1) 
     ganador=1;
 elseif ones(4,1)==diagonal4flip(1:4,1)
     ganador=1;
 elseif 2*ones(4,1)==diagonal4(1:4,2)
     ganador=2;
 elseif 2*ones(4,1)==diagonal4flip(1:4,2)
     ganador=2;
 elseif 2*ones(4,1)==diagonal4(1:4,1)
     ganador=2;
 elseif 2* ones(4,1)==diagonal4flip(1:4,1)
     ganador=2;
 end

end