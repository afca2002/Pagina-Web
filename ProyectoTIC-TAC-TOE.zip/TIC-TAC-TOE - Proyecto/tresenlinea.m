function [row,col] = tresenlinea(tablero,player)
diagonalppal=diag(tablero,0);
      diagonalppalflip=diag(flip(tablero,2),0);
      
      diagonal2(:,1)=diag(tablero,1);
      diagonal2flip(:,1)=diag(flip(tablero,2),1);
      diagonal2(:,2)=diag(tablero,-1);
      diagonal2flip(:,2)=diag(flip(tablero,2),-1);

      diagonal3(:,1)=diag(tablero,2);
      diagonal3flip(:,1)=diag(flip(tablero,2),2);
      diagonal3(:,2)=diag(tablero,-2);
      diagonal3flip(:,2)=diag(flip(tablero,2),-2);

      position=[0,0];
for j=1:3
    for i=1:7
        if tablero(i,j:j+4) == [0,player,0,player,0]
            position=[i,j+2];
            break
        elseif tablero(i,j:j+4) == [0,0,player,player,0]
            position=[i,j+1];
            break
        elseif tablero(i,j:j+4) == [0,player,player,0,0]
            position=[i,j+3];
            break
        elseif tablero(j:j+4,i) == [0;player;0;player;0]
            position=[j+2,i];
            break
        elseif tablero(j:j+4,i) == [0;0;player;player;0]
            position=[j+1,i];
            break
        elseif tablero(j:j+4,i) == [0;player;player;0;0]
            position=[j+3,i];
            break
        end
    end

    if diagonalppal(j:j+4) == [0;player;0;player;0]
        position=[j+2,j+2];
        break
    elseif diagonalppal(j:j+4) == [0;0;player;player;0]
        position=[j+1,j+1];
        break
    elseif diagonalppal(j:j+4) == [0;player;player;0;0]
        position=[j+3,j+3];
        break
    elseif diagonalppalflip(j:j+4) == [0;player;0;player;0]
        position=[j+2,6-j];
        break
    elseif diagonalppalflip(j:j+4) == [0;0;player;player;0]
        position=[j+1,7-j];
        break
    elseif diagonalppalflip(j:j+4) == [0;player;player;0;0]
        position=[j+3,5-j];
        break
    end

end
k=2;
    for j=1:2
         if diagonal2(j:j+4,k) == [0;player;0;player;0]
            position=[j+3,j+2];
            break
        elseif diagonal2(j:j+4,k) == [0;0;player;player;0]
            position=[j+2,j+1];
            break
        elseif diagonal2(j:j+4,k) == [0;player;player;0;0]
            position=[j+4,j+3];
            break
         elseif diagonal2flip(j:j+4,k) == [0;player;0;player;0]
            position=[5-j,j+2];
            break
         elseif diagonal2flip(j:j+4,k) == [0;0;player;player;0]
            position=[j+2,7-j];
            break
         elseif diagonal2flip(j:j+4,k) == [0;player;player;0;0]
            position=[4-j,j+3];
            break
        end
    end
    
    if diagonal3(1:5,k) == [0;player;0;player;0]
            position=[5,3];
        elseif diagonal3(1:5,k) == [0;0;player;player;0]
            position=[4,2];
        elseif diagonal3(1:5,k) == [0;player;player;0;0]
            position=[6,4];
         elseif diagonal3flip(1:5,k) == [0;player;0;player;0]
            position=[5,5];
         elseif diagonal3flip(1:5,k) == [0;0;player;player;0]
            position=[4,6];
         elseif diagonal3flip(1:5,k) == [0;player;player;0;0]
            position=[6,4];
    end


k=1;
    for j=1:2
         if diagonal2(j:j+4,k) == [0;player;0;player;0]
            position=[j+2,j+3];
            break
        elseif diagonal2(j:j+4,k) == [0;0;player;player;0]
            position=[j+1,j+2];
            break
        elseif diagonal2(j:j+4,k) == [0;player;player;0;0]
            position=[j+3,j+4];
            break
         elseif diagonal2flip(j:j+4,k) == [0;player;0;player;0]
            position=[j+2,5-j];
            break
         elseif diagonal2flip(j:j+4,k) == [0;0;player;player;0]
            position=[j+1,6-j];
            break
         elseif diagonal2flip(j:j+4,k) == [0;player;player;0;0]
            position=[j+3,4-j];
            break
        end
    end
    
    if diagonal3(1:5,k) == [0;player;0;player;0]
            position=[3,5];
        elseif diagonal3(1:5,k) == [0;0;player;player;0]
            position=[2,4];
        elseif diagonal3(1:5,k) == [0;player;player;0;0]
            position=[4,6];
         elseif diagonal3flip(1:5,k) == [0;player;0;player;0]
            position=[3,3];
         elseif diagonal3flip(1:5,k) == [0;0;player;player;0]
            position=[2,4];
         elseif diagonal3flip(1:5,k) == [0;player;player;0;0]
            position=[4,2];
    end
     row=position(1);
     col=position(2);
end