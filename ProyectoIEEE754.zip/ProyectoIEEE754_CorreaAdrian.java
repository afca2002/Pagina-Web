
public class ExamenBimestral_CorreaAdrian {

        public static void main(String[] args) {
            double numero = -48.75;
            int signo = numero >= 0 ? 0 : 1;
            numero = Math.abs(numero);
            int parteEntera = (int) numero;
            double parteFraccionaria = numero - parteEntera;
            String binarioEntero = enteroABinario(parteEntera);
            String binarioFraccionario = fraccionABinario(parteFraccionaria);
            int exponente = 127 + binarioEntero.length() - 1;
            System.out.println("Número que se suma al sesgo (127): " + (binarioEntero.length() - 1));
            String mantisa = binarioEntero.substring(1) + binarioFraccionario;
            mantisa = mantisa.length() > 23 ? mantisa.substring(0, 23) : mantisa;
            while (mantisa.length() < 23) {
                mantisa += "0";
            }
            String binarioExponente = enteroABinario(exponente);
            String binarioFAT32 = signo + binarioExponente + mantisa;
            String binarioCompleto = binarioEntero + "." + binarioFraccionario;
            System.out.println("Número entero: " + parteEntera);
            System.out.println("Número entero en binario: " + binarioEntero);
            System.out.println("Número decimal: " + parteFraccionaria);
            System.out.println("Número decimal en binario: " + binarioFraccionario);
            System.out.println("El número " + numero + " en binario es: " + binarioCompleto);
            System.out.println("Signo: " + signo);
            System.out.println("Exponente (127+n = sesgo): " + exponente);
            System.out.println("Mantisa: " + mantisa);
            System.out.println("El número en formato FAT32 es: " + binarioFAT32);
            calcularValoresGruposHex(binarioFAT32);
        }
    
        public static String enteroABinario(int entero) {
            if (entero == 0) {
                return "0";
            }
            StringBuilder binario = new StringBuilder();
            while (entero > 0) {
                binario.insert(0, (entero % 2));
                entero /= 2;
            }
            return binario.toString();
        }
    
        public static String fraccionABinario(double fraccion) {
            StringBuilder binario = new StringBuilder();
            while (fraccion > 0) {
                fraccion *= 2;
                int bit = (int) fraccion;
                binario.append(bit);
                fraccion -= bit;
                if (binario.length() > 10) {
                    break;
                }
            }
            return binario.toString();
        }
    
        public static void calcularValoresGruposHex(String binario) {
            System.out.println("Número en formato FAT32: " + binario);
            for (int i = 0; i < binario.length(); i += 4) {
                int fin = Math.min(i + 4, binario.length());
                String grupo = binario.substring(i, fin);
                int valorDecimal = Integer.parseInt(grupo, 2);
                String valorHexadecimal = Integer.toHexString(valorDecimal).toUpperCase();
                System.out.println("Grupo: " + grupo + " Valor hexadecimal: " + valorHexadecimal);
            }
        }
    }
    







    /* 
        
        public static void main(String[] args) {
            // Método principal 'main' que se ejecuta al iniciar el programa.
    
            double numero = -48.75;
            // Declara una variable 'numero' de tipo double y le asigna el valor -48.75.
    
            int signo = numero >= 0 ? 0 : 1;
            // Determina el signo del número: 0 si es positivo o cero, 1 si es negativo.
    
            numero = Math.abs(numero);
            // Convierte 'numero' a su valor absoluto.
    
            int parteEntera = (int) numero;
            // Extrae la parte entera del número y la almacena en 'parteEntera'.
    
            double parteFraccionaria = numero - parteEntera;
            // Calcula la parte fraccionaria del número.
    
            // Convertir a binario
            String binarioEntero = enteroABinario(parteEntera);
            // Convierte la parte entera a binario usando el método 'enteroABinario'.
    
            String binarioFraccionario = fraccionABinario(parteFraccionaria);
            // Convierte la parte fraccionaria a binario usando el método 'fraccionABinario'.
    
            // Calcular el exponente y la mantisa
            int exponente = 127 + binarioEntero.length() - 1;
            // Calcula el exponente para la representación en punto flotante.
    
            // Agregar línea para mostrar el número que se suma al sesgo
            System.out.println("Número que se suma al sesgo (127): " + (binarioEntero.length() - 1));
            // Muestra cuántos lugares se mueve la coma (número de bits a la izquierda del punto binario).
    
            String mantisa = binarioEntero.substring(1) + binarioFraccionario;
            // Combina la parte entera y fraccionaria para formar la mantisa, omitiendo el primer bit.
    
            // Asegurarse de que la mantisa tenga 23 bits
            mantisa = mantisa.length() > 23 ? mantisa.substring(0, 23) : mantisa;
            // Trunca o rellena la mantisa para que tenga exactamente 23 bits.
    
            while (mantisa.length() < 23) {
                mantisa += "0";
                // Rellena la mantisa con ceros si es necesario.
            }
    
            // Convertir el exponente a binario
            String binarioExponente = enteroABinario(exponente);
            // Convierte el exponente a binario.
    
            // Combinar signo, exponente y mantisa
            String binarioFAT32 = signo + binarioExponente + mantisa;
            // Forma la representación binaria final combinando signo, exponente y mantisa.
    
            // Mostrar los resultados
            String binarioCompleto = binarioEntero + "." + binarioFraccionario;
            // Crea una representación binaria completa del número.
    
            System.out.println("Número entero: " + parteEntera);
            // Muestra la parte entera del número.
    
            System.out.println("Número entero en binario: " + binarioEntero);
            // Muestra la parte entera en binario.
    
            System.out.println("Número decimal: " + parteFraccionaria);
            // Muestra la parte fraccionaria del número.
    
            System.out.println("Número decimal en binario: " + binarioFraccionario);
            // Muestra la parte fraccionaria en binario.
    
            System.out.println("El número " + numero + " en binario es: " + binarioCompleto);
            // Muestra la representación binaria completa del número.
    
            System.out.println("Signo: " + signo);
            // Muestra el signo del número.
    
            System.out.println("Exponente (127+n = sesgo): " + exponente);
            // Muestra el exponente calculado.
    
            System.out.println("Mantisa: " + mantisa);
            // Muestra la mantisa.
    
            System.out.println("El número en formato FAT32 es: " + binarioFAT32);
            // Muestra la representación binaria del número en formato FAT32.
    
            // Llamada al método para separar y calcular los valores hexadecimales
            calcularValoresGruposHex(binarioFAT32);
            // Llama al método 'calcularValoresGruposHex' para convertir el binario a hexadecimal.
        }
    
        public static String enteroABinario(int entero) {
            // Método que convierte un entero a binario.
    
            if (entero == 0) {
                return "0";
                // Si el entero es cero, devuelve "0".
            }
            StringBuilder binario = new StringBuilder();
            // Crea un StringBuilder para construir la representación binaria.
    
            while (entero > 0) {
                binario.insert(0, (entero % 2));
                // Inserta el resto de la división entre 2 al inicio del StringBuilder.
    
                entero /= 2;
                // Divide el entero entre 2 para la siguiente iteración.
            }
            return binario.toString();
            // Devuelve la representación binaria como una cadena.
        }
    
        public static String fraccionABinario(double fraccion) {
            // Método que convierte una fracción a binario.
    
            StringBuilder binario = new StringBuilder();
            // Crea un StringBuilder para construir la representación binaria.
    
            while (fraccion > 0) {
                fraccion *= 2;
                // Multiplica la fracción por 2.
    
                int bit = (int) fraccion;
                // Obtiene la parte entera del resultado.
    
                binario.append(bit);
                // Añade el bit al final del StringBuilder.
    
                fraccion -= bit;
                // Resta el bit de la fracción para la siguiente iteración.
    
                if (binario.length() > 10) {
                    // Limita la longitud para evitar un bucle infinito.
                    break;
                }
            }
            return binario.toString();
            // Devuelve la representación binaria como una cadena.
        }
    
        // Método para separar en grupos de 4 y calcular el valor hexadecimal
        public static void calcularValoresGruposHex(String binario) {
            // Método que convierte una cadena binaria en valores hexadecimales.
    
            System.out.println("Número en formato FAT32: " + binario);
            // Muestra el número en formato FAT32.
    
            for (int i = 0; i < binario.length(); i += 4) {
                // Itera sobre la cadena binaria en grupos de 4 bits.
    
                int fin = Math.min(i + 4, binario.length());
                // Calcula el índice final del grupo actual.
    
                String grupo = binario.substring(i, fin);
                // Obtiene el grupo de 4 bits.
    
                int valorDecimal = Integer.parseInt(grupo, 2);
                // Convierte el grupo binario a su valor decimal.
    
                String valorHexadecimal = Integer.toHexString(valorDecimal).toUpperCase();
                // Convierte el valor decimal a hexadecimal y lo convierte a mayúsculas.
    
                System.out.println("Grupo: " + grupo + " Valor hexadecimal: " + valorHexadecimal);
                // Muestra el grupo binario y su correspondiente valor hexadecimal.
            }
        }
    }
    */