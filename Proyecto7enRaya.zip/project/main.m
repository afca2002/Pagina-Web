clc;
close all;
clear all;
warning off all;

% Marco E. Benalc�zar, Ph.D.
% marco.benalcazar@epn.edu.ec
% https://laboratorio-ia.epn.edu.ec/es/

% Adding the toolbox for mnk games
addpath('Toolbox MNK Games');

% Lista de opciones:
% Opci�n 1: Agente de estudiantes vs. juego manual
% Opci�n 2: Agente del profesor vs. juego manual
% Opci�n 3: Agente de estudiantes vs. agente del profesor
% Nota: En las opciones 2 y 3 se ha inclu�do como agente del profesor uno
%       que realiza movimientos aleatorios. El agente del profesor que realiza
%       movimientos "inteligentes" se pondr� a prueba el d�a de la defensa del
%       del presente proyecto.
global option;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%     AQU� DEBE CAMBIAR EL VALOR DE LAS VARIABLES OPTION y SIZEBOARD
%
% IMPORTANTE: Colocar el valor de la variable option en 1 cuando
% quiera probar su agente con un usuario; caso contrario, coloque el valor
% en 3 cuando quiera verificar que su programa es capaz de interactuar con
% el agente el profesor. Recuerde que el agente del profesor que acompa�a
% este c�digo no es inteligente, pues realiza jugadas al azar.
% A trav�s del valor (3 � 5) que asigne a la variable sizeBoard puede
% seleccionar el tama�o del tablero.
option = 1;
numEpisodes = 1; % N�mero de veces que se repite el juego (puede tomar un
                 % valor diferente de 1 solamente cuando la variable option 
                 % est� seteada a 3. Para cuando option toma los valores 1 � 2
                 % numEpisodes se debe setear siempre a 1) 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% NO EDITAR EL SIGUIENTE C�DIGO
tictactoe7x7(option, numEpisodes);