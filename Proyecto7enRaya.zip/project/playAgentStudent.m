%function [row, col] = playAgentStudent(board)
% playAgentStudent implementa un agente que juega un juego m,n,k usando
% �rboles.
%
% Entradas:
%
%         - board: [mxn] matriz conteniendo el estado actual del juego.
%                  Cada posici�n de esta matriz contiene un elemento del
%                  conjunto {0, 1, 2}. La codificaci�n es la siguiente:
%                  0 = posici�n disponible
%                  1 = posici�n ocupada por el agente del estudiante
%                  2 = posici�n ocupada por el agente del profesor o el
%                      agente manual
% Salidas:
%
%           - row: [1x1] entero del conjunto {1, 2, ..., m} que indica la fila donde
%                  el estudiante ha colocado la marca actual
%           - col: [1x1] entero del conjunto {1, 2, ..., n} que indica la columna donde
%                  el estudiante ha colocado la marca actual
%             
%

% REEMPLAZAR LA SIGUIENTE FUNCI�N CON EL C�DIGO SU AGENTE
%[row, col] = playRandomly(board); 
%end

% Funci�n principal que implementa el agente estudiante
% Se encarga de seleccionar la mejor jugada para el estudiante en base al algoritmo minimax
% y realizarla en el tablero
function [row, col] = playAgentStudent(board)
    % Obtener el n�mero de filas y columnas del tablero
    m = size(board, 1);
    n = size(board, 2);
    % Inicializar la mejor jugada y las variables de alfa-beta
    best_move = [];
    alpha = -Inf;
    beta = Inf;
    % Profundidad m�xima y tiempo m�ximo de b�squeda
    max_depth = 3;
    max_time = 5;
    % Tiempo de inicio de la b�squeda
    start_time = tic;
    % Mejor puntuaci�n encontrada
    best_score = -Inf;
    
    % Iterar sobre todas las posiciones del tablero
    for i = 1:m
        for j = 1:n
            % Verificar si la posici�n est� disponible
            if board(i, j) == 0
                % Copiar el tablero y realizar la jugada del estudiante
                new_board = board;
                new_board(i, j) = 1;
                % Calcular la puntuaci�n de la jugada usando minimax
                score = timedMinimax(new_board, max_depth, 2, alpha, beta, start_time, max_time);
                % Imprimir la puntuaci�n de la jugada (opcional)
                fprintf('Score at position (%d, %d): %d\n', i, j, score);
                % Actualizar la mejor jugada si la puntuaci�n es mayor
                if score > best_score
                    best_score = score;
                    best_move = [i, j];
                    alpha = max(alpha, score);
                end
            end
        end
    end
    % Imprimir la mejor puntuaci�n y posici�n encontrada
    fprintf('Best Score: %d at position (%d, %d)\n', best_score, best_move(1), best_move(2));
    % Devolver la fila y columna de la mejor jugada
    row = best_move(1);
    col = best_move(2);
end

% Funci�n que realiza la b�squeda minimax con poda alfa-beta
function score = timedMinimax(board, depth, player, alpha, beta, start_time, max_time)
    % Verificar si se ha alcanzado la profundidad m�xima o el tiempo m�ximo
    if depth == 0 || toc(start_time) > max_time
        % Evaluar el tablero en la hoja del �rbol usando una funci�n de evaluaci�n
        score = evaluateBoard(board, player);
        return;
    end

    % Maximizar la puntuaci�n para el jugador actual
    if player == 1
        max_score = -Inf;
        % Iterar sobre todas las posibles jugadas
        for i = 1:size(board, 1)
            for j = 1:size(board, 2)
                % Verificar si la posici�n est� disponible
                if board(i, j) == 0
                    % Copiar el tablero y realizar la jugada del jugador
                    new_board = board;
                    new_board(i, j) = player;
                    % Verificar si el jugador ha ganado con esta jugada
                    if checkWin(new_board, player)
                        score = 1000;
                        return;
                    end
                    % Calcular la puntuaci�n de la jugada recursivamente
                    score = timedMinimax(new_board, depth-1, 2, alpha, beta, start_time, max_time);
                    % Actualizar la puntuaci�n m�xima y alfa
                    max_score = max(max_score, score);
                    alpha = max(alpha, max_score);
                    % Podar si beta es menor o igual que alfa
                    if beta <= alpha
                        score = max_score;
                        return;
                    end
                end
            end
        end
        score = max_score;
    % Minimizar la puntuaci�n para el oponente
    else
        min_score = Inf;
        % Iterar sobre todas las posibles jugadas
        for i = 1:size(board, 1)
            for j = 1:size(board, 2)
                % Verificar si la posici�n est� disponible
                if board(i, j) == 0
                    % Copiar el tablero y realizar la jugada del oponente
                    new_board = board;
                    new_board(i, j) = player;
                    % Verificar si el oponente ha ganado con esta jugada
                    if checkWin(new_board, player)
                        score = -1000;
                        return;
                    end
                    % Calcular la puntuaci�n de la jugada recursivamente
                    score = timedMinimax(new_board, depth-1, 1, alpha, beta, start_time, max_time);
                    % Actualizar la puntuaci�n m�nima y beta
                    min_score = min(min_score, score);
                    beta = min(beta, min_score);
                    % Podar si beta es menor o igual que alfa
                    if beta <= alpha
                        score = min_score;
                        return;
                    end
                end
            end
        end
        score = min_score;
    end
end

% Funci�n de evaluaci�n del tablero
% Asigna una puntuaci�n a cada estado del tablero para evaluar la posici�n del jugador
function score = evaluateBoard(board, player)
    % Inicializar la puntuaci�n del tablero y calcular el oponente del jugador
    score = 0;
    opponent = 3 - player;

    % Calcular la puntuaci�n de las filas, columnas y diagonales
    for i = 1:size(board, 1)
        % Calcular la puntuaci�n de la fila actual
        row_score = sum(board(i, :));
        % Calcular la puntuaci�n de la columna actual
        col_score = sum(board(:, i));
        % Calcular la puntuaci�n de la diagonal principal
        diag_score = sum(diag(board));
        % Calcular la puntuaci�n de la diagonal secundaria
        anti_diag_score = sum(diag(fliplr(board)));
        % Sumar la puntuaci�n de las l�neas llamando a evaluateLine
        score = score + evaluateLine(row_score, player);
        score = score + evaluateLine(col_score, player);
        score = score + evaluateLine(diag_score, player);
        score = score + evaluateLine(anti_diag_score, player);
    end
    
    % Evaluar posibles configuraciones de victoria y derrota en las filas
    for i = 1:size(board, 1)
        % Calcular la puntuaci�n de la fila actual
        row_score = sum(board(i, :));
        % Evaluar las diferentes configuraciones de victoria y derrota
        if row_score == opponent * 2
            score = score + 10;
        elseif row_score == opponent * 3
            score = score - 100; % Penalizar la victoria potencial del oponente
        elseif row_score == player * 2
            score = score + 20; % Favorecer la victoria potencial del jugador
        elseif row_score == player * 3
            score = score + 100; % Victoria del jugador
        end
    end
    
    % Evaluar posibles configuraciones de victoria y derrota en las columnas
    for i = 1:size(board, 2)
        % Calcular la puntuaci�n de la columna actual
        col_score = sum(board(:, i));
        % Evaluar las diferentes configuraciones de victoria y derrota
        if col_score == opponent * 2
            score = score + 10;
        elseif col_score == opponent * 3
            score = score - 100;
        elseif col_score == player * 2
            score = score + 20;
        elseif col_score == player * 3
            score = score + 100;
        end
    end
    
    % Evaluar posibles configuraciones de victoria y derrota en la diagonal principal
    diag_score = sum(diag(board));
    % Evaluar las diferentes configuraciones de victoria y derrota
    if diag_score == opponent * 2
        score = score + 10;
    elseif diag_score == opponent * 3
        score = score - 100;
    elseif diag_score == player * 2
        score = score + 20;
    elseif diag_score == player * 3
        score = score + 100;
    end
    
    % Evaluar posibles configuraciones de victoria y derrota en la diagonal secundaria
    anti_diag_score = sum(diag(fliplr(board)));
    % Evaluar las diferentes configuraciones de victoria y derrota
    if anti_diag_score == opponent * 2
        score = score + 10;
    elseif anti_diag_score == opponent * 3
        score = score - 100;
    elseif anti_diag_score == player * 2
        score = score + 20;
    elseif anti_diag_score == player * 3
        score = score + 100;
    end
end


% Funci�n que eval�a la puntuaci�n de una l�nea
% Determina si la l�nea contiene una configuraci�n ganadora, perdedora o neutra
function score = evaluateLine(line_score, player, win_length)
    % Establecer la longitud de la l�nea por defecto si no se proporciona
    if nargin < 3
        win_length = 3;
    end
    % Evaluar la puntuaci�n de la l�nea
    if line_score == player * win_length
        score = 100;
    elseif line_score == (3 - player) * win_length
        score = -100;
    else
        score = 0;
    end
end

% Funci�n que verifica si un jugador ha ganado en el tablero
function result = checkWin(board, player)
    % Inicializar el resultado como falso
    result = 0;
    % Verificar si el jugador ha ganado en alguna l�nea
    for i = 1:size(board, 1)
        for j = 1:size(board, 2)
            if board(i, j) == player
                % Verificar si el jugador ha ganado en una l�nea horizontal
                if j <= size(board, 2) - 2 && all(board(i, j:j+2) == player)
                    result = 1;
                    return;
                end
                % Verificar si el jugador ha ganado en una l�nea vertical
                if i <= size(board, 1) - 2 && all(board(i:i+2, j) == player)
                    result = 1;
                    return;
                end
                % Verificar si el jugador ha ganado en una l�nea diagonal
                if i <= size(board, 1) - 2 && j <= size(board, 2) - 2 && all(diag(board(i:i+2, j:j+2)) == player)
                    result = 1;
                    return;
                end
                % Verificar si el jugador ha ganado en una l�nea diagonal invertida
                if i <= size(board, 1) - 2 && j >= 3 && all(diag(flipud(board(i:i+2, j-2:j))) == player)
                    result = 1;
                    return;
                end
            end
        end
    end
end
